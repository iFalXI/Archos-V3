// Fal Hanya Menambah kan fitur dan fix fitur yg eror, dilarang jual sc, reupload? credit #Fal



const fs = require('fs')
const chalk = require('chalk')

global.gr = 'https://wa.me/6283842724648?text=bang'
global.ig = 'https://www.youtube.com/@iFalXI' // Ig Lu
global.ofc = 'youtube.com/@iFalXI' // yt lu
global.okta = 'https://github.com/iFalXI'
global.gh = 'https://github.com/iFalXI' // github lu
global.saluran = 'https://chat.whatsapp.com/DgczB8KDjx3KN1gorp58pY' // gc wa lu
global.email = 'iFalZoyy2@gmail.com' //serah
global.region = 'indonesia' // serah
global.dana = '085280442946' // dana lu
global.gopay = '085280442946' // gopay lu
global.pulsa = '085280442946'
//—————「 Set Nama Own & Bot 」—————//
global.ownername = 'iFal' //ubah jadi nama mu, note tanda ' gausah di hapus!
//=================================================//
global.owner = ['6285753806526'] // ubah aja pake nomor lu
global.premium = ['6285280442946']
//==========================BY Hw Mods=======================//
global.lolkey = 'a8e86232771f9bc1826742c1'
global.zenz = 'zenzkey_41b4fe7a5d' // https://api.zahwazein.xyz
global.keyopenai = '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'
//====================BY Hw Mods=============================//
global.botname = 'Archos-BotMD' //ubah jadi nama bot mu, note tanda ' gausah di hapus!
global.packname = 'Archos' // ubah aja ini nama sticker
global.ta = '•' //cuma simbol
global.author = 'Bot!' // ubah aja ini nama sticker
global.prefa = ['','!','.',',','🐤','🗿']
global.sessionName = 'oka' //Gausah Juga
global.sp = '⭔' // Gausah Juga
global.wlcm = []
global.wlcmm = []
global.anticall = true
//=================================================//


//imgnya disini
global.thum = fs.readFileSync("./baseoka/image/thum.jpeg") 
global.good = fs.readFileSync("./baseoka/image/good.jpeg") 
global.vidmenu = fs.readFileSync("./baseoka/video/mainmenu.mp4")

global.mess = {
    done: 'Done Ya Kaka',
    admin: 'Fitur ini buat _*Admin Group*_ saja kak',
    botAdmin: 'Perintah Ini Hanya Bisa Digunakan Ketika Bot Menjadi Admin Group !',
    owner: 'Fitur khusus fal Saja Kak',
    group: 'Fitur ini buat _*Group Chat*_ saja kak',
    private: 'Fitur ini buat _*Admin Group*_ saja kak',
    wait: 'Lu olang tunggu bentar loo',
    endLimit: 'Lu olang punya limit sudah abis, tunggu jam 12 malam untuk reset',
    error: '*Fitur sedang eror...*',
    prem : 'Fitur ini buat _*Member Premium*_ saja kak'
}
//=================================================//
//Gausah Juga
global.limitawal = {
    premium: "Infinity",
    free: 100
}

//rpg
global.buruan = {
   ikan: 5,
   ayam: 5,
   kelinci: 5,
   domba: 5,
   sapi: 5,
   gajah: 5
}
global.rpg = {
   darahawal: 100,
   besiawal: 5,
   goldawal: 1,
   emeraldawal: 1,
   umpanawal: 1,
   potionawal: 1
}
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})